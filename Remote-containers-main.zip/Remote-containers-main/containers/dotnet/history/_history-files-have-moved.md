**IMPORTANT NOTE: We're starting to migrate contents of this repo to the [devcontainers org](https://github.com/devcontainers), as part of the work on the [open dev container specification](https://containers.dev).**

**We'll now be publishing the `dotnet` image from [devcontainers/images/src/dotnet](https://github.com/devcontainers/images/tree/main/src/dotnet).**

**For more details, you can review the [announcement issue](https://github.com/microsoft/vscode-dev-containers/issues/1589).**
