(ns sample.main)

(println "Hello world")
